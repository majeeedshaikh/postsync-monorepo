/* routes/authRoutes.js
   – handles signup / login
   – starts Facebook-Login flow for Instagram Business
   – processes callback and stores the Page token + IG Business ID
*/
require('dotenv').config();               // MUST be first
const express  = require('express');
const axios    = require('axios');
const { v4: uuidv4 } = require('uuid');
const jwt      = require('jsonwebtoken');
const User     = require('../models/User');
const authenticateToken = require('../middleware/auth');

const router   = express.Router();
const oauthStateStore = new Map();

/* ────────────────────────
   ENV
──────────────────────── */
const {
  JWT_SECRET        = 'postsyncsupersecretkey123',
  FB_APP_ID,
  FB_APP_SECRET,
  BASE_URL,          // e.g. https://deb0-182-177-2-88.ngrok-free.app
  FRONTEND_URL       = 'http://localhost:3001'
} = process.env;

/* ────────────────────────
   USER SIGNUP / LOGIN
──────────────────────── */
// Register a new user
router.post("/signup", async (req, res) => {
  try {
    const { fullName, email, password } = req.body

    // Check if user already exists
    const userExists = await User.findOne({ email })
    if (userExists) {
      return res.status(400).json({ message: "User already exists" })
    }

    // Create new user
    const user = new User({
      fullName,
      email,
      password,
    })

    await user.save()

    // Generate JWT token
    const token = jwt.sign({ id: user._id, email: user.email }, JWT_SECRET, { expiresIn: "1h" })

    res.status(201).json({
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
      },
    })
  } catch (error) {
    console.error("Error in signup:", error)
    res.status(500).json({ message: "Server error" })
  }
})

// Login user
router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Check if user exists
    const user = await User.findOne({ email })
    if (!user) {
      return res.status(400).json({ message: "Invalid credentials" })
    }

    // Validate password
    const isMatch = await user.comparePassword(password)
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid credentials" })
    }

    // Generate JWT token
    const token = jwt.sign({ id: user._id, email: user.email }, JWT_SECRET, { expiresIn: "1h" })

    res.json({
      token,
      user: {
        id: user._id,
        fullName: user.fullName,
        email: user.email,
      },
    })
  } catch (error) {
    console.error("Error in login:", error)
    res.status(500).json({ message: "Server error" })
  }
})

/* ────────────────────────
   1.  START OAUTH
──────────────────────── */
router.get('/instagram', authenticateToken, (req, res) => {
  try {
    const state = uuidv4();
    // Store state with user ID for 10 minutes
    oauthStateStore.set(state, { userId: req.user.id, expires: Date.now() + 10 * 60 * 1000 });

    const redirectUri = `${BASE_URL}/api/auth/facebook/callback`;      // must match FB dashboard
    const scopes = [
      'pages_read_engagement',
      'pages_manage_posts',
      'instagram_basic',
      'instagram_content_publish',
      'instagram_manage_insights'
    ].join(',');

    const authUrl =
      `https://www.facebook.com/v18.0/dialog/oauth` +
      `?client_id=${FB_APP_ID}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&state=${state}` +
      `&scope=${encodeURIComponent(scopes)}` +
      `&response_type=code`;

    console.log('[OAuth] redirecting to:', authUrl);
    return res.redirect(authUrl);
    console.log('[OAuth] here');  
  } catch (error) {
    console.error('[OAuth] Error starting authentication:', error);
    return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=Failed+to+start+auth+flow`);
  }
});

/* ────────────────────────
   2.  HANDLE CALLBACK
──────────────────────── */
router.get('/facebook/callback', async (req, res) => {
  console.log('[OAuth] callback received:', req.query);
  try {
    /* 2-a  Validate incoming params */
    const { code, state } = req.query;
    
    if (!code || !state) {
      console.error('[OAuth] Missing code or state');
      return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=Missing+code+or+state`);
    }
    
    const stateData = oauthStateStore.get(state);
    oauthStateStore.delete(state);                         // one-time use
    
    if (!stateData || stateData.expires < Date.now()) {
      console.error('[OAuth] Invalid or expired state');
      return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=Invalid+or+expired+state`);
    }
    
    const userId = stateData.userId;
    console.log(`[OAuth] Processing for user: ${userId}`);

    /* 2-b  Exchange CODE → short-lived user token */
    const redirectUri = `${BASE_URL}/api/auth/facebook/callback`;
    console.log(`[OAuth] Exchanging code for token with redirect URI: ${redirectUri}`);
    
    const shortRes = await axios.get('https://graph.facebook.com/v18.0/oauth/access_token', {
      params: {
        client_id: FB_APP_ID,
        client_secret: FB_APP_SECRET,
        redirect_uri: redirectUri,
        code
      }
    });
    
    if (!shortRes.data.access_token) {
      console.error('[OAuth] Failed to get short-lived token:', shortRes.data);
      return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=Failed+to+get+token`);
    }
    
    const shortToken = shortRes.data.access_token;
    console.log('[OAuth] Short-lived token acquired');

    /* 2-c  Short-lived → long-lived user token */
    const longRes = await axios.get('https://graph.facebook.com/v18.0/oauth/access_token', {
      params: {
        grant_type: 'fb_exchange_token',
        client_id: FB_APP_ID,
        client_secret: FB_APP_SECRET,
        fb_exchange_token: shortToken
      }
    });
    
    if (!longRes.data.access_token) {
      console.error('[OAuth] Failed to get long-lived token:', longRes.data);
      return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=Failed+to+get+long+token`);
    }
    
    const userLongToken = longRes.data.access_token;
    console.log('[OAuth] Long-lived token acquired');

    /* 2-d  List Pages user manages */
    const pagesRes = await axios.get('https://graph.facebook.com/v18.0/me/accounts', {
      params: { access_token: userLongToken }
    });
    
    const pages = pagesRes.data.data || [];
    console.log(`[OAuth] Found ${pages.length} Facebook Pages`);
    
    if (!pages.length) {
      return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=No+Facebook+Pages+found`);
    }

    /* 2-e  Find a Page with an IG Business Account */
    let igBusinessAccountId = null;
    let pageToken = null;
    let pageId = null;
    let pageName = null;

    for (const page of pages) {
      try {
        console.log(`[OAuth] Checking page "${page.name}" (${page.id}) for Instagram Business`);
        
        const pg = await axios.get(`https://graph.facebook.com/v18.0/${page.id}`, {
          params: {
            fields: 'instagram_business_account',
            access_token: page.access_token
          }
        });
        
        if (pg.data.instagram_business_account) {
          igBusinessAccountId = pg.data.instagram_business_account.id;
          pageToken = page.access_token;
          pageId = page.id;
          pageName = page.name;
          console.log(`[OAuth] Found Instagram Business account: ${igBusinessAccountId} on page "${pageName}"`);
          break;
        }
      } catch (e) { 
        console.error(`[OAuth] Error checking page ${page.id}:`, e.message);
      }
    }

    if (!igBusinessAccountId) {
      console.error('[OAuth] No Instagram Business accounts found on any pages');
      return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=No+Instagram+Business+account+linked+to+any+page`);
    }

    /* 2-f  Fetch IG username for display */
    console.log(`[OAuth] Fetching Instagram profile for account ID: ${igBusinessAccountId}`);
    const igRes = await axios.get(`https://graph.facebook.com/v18.0/${igBusinessAccountId}`, {
      params: {
        fields: 'username,name,profile_picture_url',
        access_token: pageToken
      }
    });
    
    const { username, name: igName, profile_picture_url } = igRes.data;
    console.log(`[OAuth] Instagram username: ${username}, name: ${igName}`);

    /* 2-g  Save into connectedAccounts */
    const user = await User.findById(userId);
    if (!user) {
      console.error(`[OAuth] User ${userId} not found`);
      return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=User+not+found`);
    }
    
    const newAccount = {
      platform: 'instagram',
      isActive: true,
      accountId: igBusinessAccountId, // Add this field
      accessToken: pageToken,         // PAGE TOKEN (not encrypted)
      pageId,
      igBusinessAccountId,
      accountName: igName || pageName,
      username,
      profilePicture: profile_picture_url,
      connectedAt: new Date()
    };
    
    const existingIndex = user.connectedAccounts.findIndex(a => 
      a.platform === 'instagram' && a.igBusinessAccountId === igBusinessAccountId);
    
    if (existingIndex >= 0) {
      console.log(`[OAuth] Updating existing Instagram account for user ${userId}`);
      user.connectedAccounts[existingIndex] = newAccount;
    } else {
      console.log(`[OAuth] Adding new Instagram account for user ${userId}`);
      user.connectedAccounts.push(newAccount);
    }
    
    await user.save();
    console.log(`[OAuth] Saved Instagram account for user ${userId}`);

    console.log(`[OAuth] Instagram account "${username}" connected for user ${userId}`);
    return res.redirect(`${FRONTEND_URL}/dashboard?accountConnected=instagram&username=${encodeURIComponent(username)}`);
    
  } catch (err) {
    const errorMessage = err.response?.data?.error?.message || err.message;
    console.error('[OAuth] Instagram auth error:', errorMessage);
    
    // Enhanced error details
    if (err.response?.data) {
      console.error('[OAuth] API error details:', JSON.stringify(err.response.data));
    }
    
    return res.redirect(`${FRONTEND_URL}/dashboard?error=instagram_auth_failed&message=${encodeURIComponent(errorMessage)}`);
  }
});

module.exports = router;